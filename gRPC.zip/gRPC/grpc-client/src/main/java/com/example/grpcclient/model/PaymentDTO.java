package com.example.grpcclient.model;
import lombok.Data;

@Data
public class PaymentDTO {
    private int id;
    private String payer;
    private String payee;
    private double amount;
    private String currency;
    private String date;
    private String status;
}
