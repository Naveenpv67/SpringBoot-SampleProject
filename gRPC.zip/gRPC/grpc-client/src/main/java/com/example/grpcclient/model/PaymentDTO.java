package com.example.grpcclient.model;

import lombok.Data;

/**
 * Data Transfer Object representing a Payment.
 * @author HDFC-EF
 */
@Data
public class PaymentDTO {
    /**
     * Unique identifier for the payment.
     */
    private int id;

    /**
     * Name of the payer.
     */
    private String payer;

    /**
     * Name of the payee.
     */
    private String payee;

    /**
     * Amount of the payment.
     */
    private double amount;

    /**
     * Currency of the payment.
     */
    private String currency;

    /**
     * Date of the payment.
     */
    private String date;

    /**
     * Status of the payment.
     */
    private String status;
}
