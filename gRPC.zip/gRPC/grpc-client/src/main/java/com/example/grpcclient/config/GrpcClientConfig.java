//package com.example.grpcclient.config;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import com.example.protobuf.PaymentServiceGrpc;
//
//import net.devh.boot.grpc.client.inject.GrpcClient;
//
//@Configuration
//public class GrpcClientConfig {
//
//    @GrpcClient("paymentService")
//    private PaymentServiceGrpc.PaymentServiceBlockingStub paymentServiceBlockingStub;
//
//    @Bean
//    public PaymentServiceGrpc.PaymentServiceBlockingStub paymentServiceBlockingStub() {
//        return paymentServiceBlockingStub;
//    }
//}
