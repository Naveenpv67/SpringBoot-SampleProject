package com.example.grpcclient.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.example.grpcclient.model.PaymentDTO;
import com.example.protobuf.PaymentProto.Empty;
import com.example.protobuf.PaymentProto.Payment;
import com.example.protobuf.PaymentProto.PaymentListResponse;
import com.example.protobuf.PaymentProto.PaymentRequest;
import com.example.protobuf.PaymentProto.PaymentResponse;
import com.example.protobuf.PaymentServiceGrpc;

import net.devh.boot.grpc.client.inject.GrpcClient;

@Component
public class PaymentGrpcClient {

    @GrpcClient(value = "paymentService")
    private PaymentServiceGrpc.PaymentServiceBlockingStub stub;

    public PaymentDTO getPayment(int id) {
        PaymentRequest request = PaymentRequest.newBuilder().setId(id).build();
        PaymentResponse response = stub.getPayment(request);
        return convertToDTO(response.getPayment());
    }

    public PaymentDTO createPayment(PaymentDTO paymentDTO) {
        Payment payment = convertToProto(paymentDTO);
        PaymentResponse response = stub.createPayment(payment);
        return convertToDTO(response.getPayment());
    }

    public PaymentDTO updatePayment(PaymentDTO paymentDTO) {
        Payment payment = convertToProto(paymentDTO);
        PaymentResponse response = stub.updatePayment(payment);
        return convertToDTO(response.getPayment());
    }

    public PaymentDTO deletePayment(int id) {
        PaymentRequest request = PaymentRequest.newBuilder().setId(id).build();
        PaymentResponse response = stub.deletePayment(request);
        return convertToDTO(response.getPayment());
    }

    public List<PaymentDTO> listPayments() {
        Empty request = Empty.newBuilder().build();
        PaymentListResponse response = stub.listPayments(request);
        return response.getPaymentsList().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    private PaymentDTO convertToDTO(Payment payment) {
        PaymentDTO dto = new PaymentDTO();
        dto.setId(payment.getId());
        dto.setPayer(payment.getPayer());
        dto.setPayee(payment.getPayee());
        dto.setAmount(payment.getAmount());
        dto.setCurrency(payment.getCurrency());
        dto.setDate(payment.getDate());
        dto.setStatus(payment.getStatus());
        return dto;
    }

    private Payment convertToProto(PaymentDTO dto) {
        return Payment.newBuilder()
                .setId(dto.getId())
                .setPayer(dto.getPayer())
                .setPayee(dto.getPayee())
                .setAmount(dto.getAmount())
                .setCurrency(dto.getCurrency())
                .setDate(dto.getDate())
                .setStatus(dto.getStatus())
                .build();
    }
}
