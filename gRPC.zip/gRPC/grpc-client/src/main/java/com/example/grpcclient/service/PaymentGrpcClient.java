package com.example.grpcclient.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.example.grpcclient.model.PaymentDTO;
import com.example.protobuf.PaymentProto.EmptyPayment;
import com.example.protobuf.PaymentProto.Payment;
import com.example.protobuf.PaymentProto.PaymentListResponse;
import com.example.protobuf.PaymentProto.PaymentRequest;
import com.example.protobuf.PaymentProto.PaymentResponse;
import com.example.protobuf.PaymentServiceGrpc;

import net.devh.boot.grpc.client.inject.GrpcClient;

/**
 * gRPC client for interacting with the Payment Service.
 * This client provides methods for retrieving, creating, updating, deleting, and listing payments.
 *
 * @author HDFC-EF
 */
@Component
public class PaymentGrpcClient {

    @GrpcClient(value = "paymentService")
    private PaymentServiceGrpc.PaymentServiceBlockingStub stub;

    /**
     * Retrieves a Payment by its ID.
     *
     * @param id The ID of the payment to retrieve.
     * @return The PaymentDTO object representing the payment.
     */
    public PaymentDTO getPayment(int id) {
        PaymentRequest request = PaymentRequest.newBuilder().setId(id).build();
        PaymentResponse response = stub.getPayment(request);
        return convertToDTO(response.getPayment());
    }

    /**
     * Creates a new Payment.
     *
     * @param paymentDTO The PaymentDTO object containing the payment details.
     * @return The created PaymentDTO object.
     */
    public PaymentDTO createPayment(PaymentDTO paymentDTO) {
        Payment payment = convertToProto(paymentDTO);
        PaymentResponse response = stub.createPayment(payment);
        return convertToDTO(response.getPayment());
    }

    /**
     * Updates an existing Payment.
     *
     * @param paymentDTO The PaymentDTO object containing the updated payment details.
     * @return The updated PaymentDTO object.
     */
    public PaymentDTO updatePayment(PaymentDTO paymentDTO) {
        Payment payment = convertToProto(paymentDTO);
        PaymentResponse response = stub.updatePayment(payment);
        return convertToDTO(response.getPayment());
    }

    /**
     * Deletes a Payment by its ID.
     *
     * @param id The ID of the payment to delete.
     * @return The deleted PaymentDTO object.
     */
    public PaymentDTO deletePayment(int id) {
        PaymentRequest request = PaymentRequest.newBuilder().setId(id).build();
        PaymentResponse response = stub.deletePayment(request);
        return convertToDTO(response.getPayment());
    }

    /**
     * Retrieves a list of all Payments.
     *
     * @return A list of PaymentDTO objects representing all payments.
     */
    public List<PaymentDTO> listPayments() {
    	EmptyPayment request = EmptyPayment.newBuilder().build();
        PaymentListResponse response = stub.listPayments(request);
        return response.getPaymentsList().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Converts a Payment Protobuf object to a PaymentDTO object.
     *
     * @param payment The Payment Protobuf object to convert.
     * @return The converted PaymentDTO object.
     */
    private PaymentDTO convertToDTO(Payment payment) {
        PaymentDTO dto = new PaymentDTO();
        dto.setId(payment.getId());
        dto.setPayer(payment.getPayer());
        dto.setPayee(payment.getPayee());
        dto.setAmount(payment.getAmount());
        dto.setCurrency(payment.getCurrency());
        dto.setDate(payment.getDate());
        dto.setStatus(payment.getStatus());
        return dto;
    }

    /**
     * Converts a PaymentDTO object to a Payment Protobuf object.
     *
     * @param dto The PaymentDTO object to convert.
     * @return The converted Payment Protobuf object.
     */
    private Payment convertToProto(PaymentDTO dto) {
        return Payment.newBuilder()
                .setId(dto.getId())
                .setPayer(dto.getPayer())
                .setPayee(dto.getPayee())
                .setAmount(dto.getAmount())
                .setCurrency(dto.getCurrency())
                .setDate(dto.getDate())
                .setStatus(dto.getStatus())
                .build();
    }
}
