package com.example.grpcclient.service;

import com.example.protobuf.CurrencyExchangeProto;
import com.example.protobuf.CurrencyExchangeServiceGrpc;
import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;

import java.util.HashMap;
import java.util.Map;

@GrpcService
public class CurrencyExchangeServiceImpl extends CurrencyExchangeServiceGrpc.CurrencyExchangeServiceImplBase {

    private static final Map<String, Double> exchangeRates = new HashMap<>();

    static {
        // Example exchange rates
        exchangeRates.put("USD_INR", 74.0);
        exchangeRates.put("INR_USD", 1 / 74.0);
        exchangeRates.put("EUR_INR", 88.0);
        exchangeRates.put("INR_EUR", 1 / 88.0);
        exchangeRates.put("GBP_INR", 102.0);
        exchangeRates.put("INR_GBP", 1 / 102.0);
        exchangeRates.put("AUD_INR", 54.0);
        exchangeRates.put("INR_AUD", 1 / 54.0);
        exchangeRates.put("CAD_INR", 58.0);
        exchangeRates.put("INR_CAD", 1 / 58.0);
        exchangeRates.put("SGD_INR", 54.5);
        exchangeRates.put("INR_SGD", 1 / 54.5);
        exchangeRates.put("JPY_INR", 0.67);
        exchangeRates.put("INR_JPY", 1 / 0.67);
        exchangeRates.put("CNY_INR", 11.5);
        exchangeRates.put("INR_CNY", 1 / 11.5);
        exchangeRates.put("AED_INR", 20.2);
        exchangeRates.put("INR_AED", 1 / 20.2);
        exchangeRates.put("SAR_INR", 19.7);
        exchangeRates.put("INR_SAR", 1 / 19.7);
        exchangeRates.put("CHF_INR", 81.0);
        exchangeRates.put("INR_CHF", 1 / 81.0);
        exchangeRates.put("ZAR_INR", 4.9);
        exchangeRates.put("INR_ZAR", 1 / 4.9);
        exchangeRates.put("NZD_INR", 50.0);
        exchangeRates.put("INR_NZD", 1 / 50.0);
        exchangeRates.put("THB_INR", 2.2);
        exchangeRates.put("INR_THB", 1 / 2.2);
        exchangeRates.put("MYR_INR", 17.8);
        exchangeRates.put("INR_MYR", 1 / 17.8);
        exchangeRates.put("KRW_INR", 0.063);
        exchangeRates.put("INR_KRW", 1 / 0.063);
        exchangeRates.put("HKD_INR", 9.5);
        exchangeRates.put("INR_HKD", 1 / 9.5);
    }

    @Override
    public void exchangeCurrency(CurrencyExchangeProto.CurrencyExchangeRequest request, StreamObserver<CurrencyExchangeProto.CurrencyExchangeResponse> responseObserver) {
        double exchangeRate = getExchangeRate(request.getFromCurrency(), request.getToCurrency());
        double exchangedAmount = request.getAmount() * exchangeRate;

        CurrencyExchangeProto.CurrencyExchangeResponse response = CurrencyExchangeProto.CurrencyExchangeResponse.newBuilder()
                .setExchangedAmount(exchangedAmount)
                .setFromCurrency(request.getFromCurrency())
                .setToCurrency(request.getToCurrency())
                .setExchangeRate(exchangeRate)
                .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void getExchangeRate(CurrencyExchangeProto.CurrencyExchangeRateRequest request, StreamObserver<CurrencyExchangeProto.CurrencyExchangeRateResponse> responseObserver) {
        double exchangeRate = getExchangeRate(request.getFromCurrency(), request.getToCurrency());

        CurrencyExchangeProto.CurrencyExchangeRateResponse response = CurrencyExchangeProto.CurrencyExchangeRateResponse.newBuilder()
                .setExchangeRate(exchangeRate)
                .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void listExchangeRates(CurrencyExchangeProto.EmptyCurrencyExchange request, StreamObserver<CurrencyExchangeProto.CurrencyExchangeRateListResponse> responseObserver) {
        CurrencyExchangeProto.CurrencyExchangeRateListResponse.Builder responseBuilder = CurrencyExchangeProto.CurrencyExchangeRateListResponse.newBuilder();

        for (Map.Entry<String, Double> entry : exchangeRates.entrySet()) {
            String[] currencies = entry.getKey().split("_");
            CurrencyExchangeProto.CurrencyExchangeRateResponse rateResponse = CurrencyExchangeProto.CurrencyExchangeRateResponse.newBuilder()
                    .setFromCurrency(currencies[0])
                    .setToCurrency(currencies[1])
                    .setExchangeRate(entry.getValue())
                    .build();
            responseBuilder.addExchangeRates(rateResponse);
        }

        responseObserver.onNext(responseBuilder.build());
        responseObserver.onCompleted();
    }

    private double getExchangeRate(String fromCurrency, String toCurrency) {
        String key = fromCurrency + "_" + toCurrency;
        return exchangeRates.getOrDefault(key, 1.0); // Default exchange rate if not found
    }
}
