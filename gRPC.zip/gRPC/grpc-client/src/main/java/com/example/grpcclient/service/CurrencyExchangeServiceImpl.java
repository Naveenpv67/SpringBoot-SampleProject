package com.example.grpcclient.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.example.protobuf.CurrencyExchangeProto;
import com.example.protobuf.CurrencyExchangeServiceGrpc;

import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;

/**
 * Implementation of the CurrencyExchangeService gRPC service.
 * This service provides currency exchange rate information and performs currency conversions.
 *
 * @author HDFC-EF
 */
@GrpcService
public class CurrencyExchangeServiceImpl extends CurrencyExchangeServiceGrpc.CurrencyExchangeServiceImplBase {

    private static final Logger logger = LoggerFactory.getLogger(CurrencyExchangeServiceImpl.class);
    private static final Map<String, Double> exchangeRates = new HashMap<>();

    static {
        // Example exchange rates
        exchangeRates.put("USD_INR", 74.0);
        exchangeRates.put("INR_USD", 1 / 74.0);
        exchangeRates.put("EUR_INR", 88.0);
        exchangeRates.put("INR_EUR", 1 / 88.0);
        exchangeRates.put("GBP_INR", 102.0);
        exchangeRates.put("INR_GBP", 1 / 102.0);
        exchangeRates.put("AUD_INR", 54.0);
        exchangeRates.put("INR_AUD", 1 / 54.0);
        exchangeRates.put("CAD_INR", 58.0);
        exchangeRates.put("INR_CAD", 1 / 58.0);
        exchangeRates.put("SGD_INR", 54.5);
        exchangeRates.put("INR_SGD", 1 / 54.5);
        exchangeRates.put("JPY_INR", 0.67);
        exchangeRates.put("INR_JPY", 1 / 0.67);
        exchangeRates.put("CNY_INR", 11.5);
        exchangeRates.put("INR_CNY", 1 / 11.5);
        exchangeRates.put("AED_INR", 20.2);
        exchangeRates.put("INR_AED", 1 / 20.2);
        exchangeRates.put("SAR_INR", 19.7);
        exchangeRates.put("INR_SAR", 1 / 19.7);
        exchangeRates.put("CHF_INR", 81.0);
        exchangeRates.put("INR_CHF", 1 / 81.0);
        exchangeRates.put("ZAR_INR", 4.9);
        exchangeRates.put("INR_ZAR", 1 / 4.9);
        exchangeRates.put("NZD_INR", 50.0);
        exchangeRates.put("INR_NZD", 1 / 50.0);
        exchangeRates.put("THB_INR", 2.2);
        exchangeRates.put("INR_THB", 1 / 2.2);
        exchangeRates.put("MYR_INR", 17.8);
        exchangeRates.put("INR_MYR", 1 / 17.8);
        exchangeRates.put("KRW_INR", 0.063);
        exchangeRates.put("INR_KRW", 1 / 0.063);
        exchangeRates.put("HKD_INR", 9.5);
        exchangeRates.put("INR_HKD", 1 / 9.5);
    }

    /**
     * Exchanges an amount from one currency to another using the defined exchange rates.
     *
     * @param request          The currency exchange request containing the fromCurrency, toCurrency, and amount.
     * @param responseObserver The stream observer to send the response back to the client.
     */
    @Override
    public void exchangeCurrency(CurrencyExchangeProto.CurrencyExchangeRequest request, StreamObserver<CurrencyExchangeProto.CurrencyExchangeResponse> responseObserver) {
        logger.info("Received exchangeCurrency request: fromCurrency={}, toCurrency={}, amount={}", request.getFromCurrency(), request.getToCurrency(), request.getAmount());
        double exchangeRate = getExchangeRate(request.getFromCurrency(), request.getToCurrency());
        double exchangedAmount = request.getAmount() * exchangeRate;

        CurrencyExchangeProto.CurrencyExchangeResponse response = CurrencyExchangeProto.CurrencyExchangeResponse.newBuilder()
                .setExchangedAmount(exchangedAmount)
                .setFromCurrency(request.getFromCurrency())
                .setToCurrency(request.getToCurrency())
                .setExchangeRate(exchangeRate)
                .build();

        logger.info("Sending exchangeCurrency response: exchangedAmount={}, fromCurrency={}, toCurrency={}, exchangeRate={}", exchangedAmount, request.getFromCurrency(), request.getToCurrency(), exchangeRate);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    /**
     * Retrieves the exchange rate for a given currency pair.
     *
     * @param request          The currency exchange rate request containing the fromCurrency and toCurrency.
     * @param responseObserver The stream observer to send the response back to the client.
     */
    @Override
    public void getExchangeRate(CurrencyExchangeProto.CurrencyExchangeRateRequest request, StreamObserver<CurrencyExchangeProto.CurrencyExchangeRateResponse> responseObserver) {
        logger.info("Received getExchangeRate request: fromCurrency={}, toCurrency={}", request.getFromCurrency(), request.getToCurrency());
        double exchangeRate = getExchangeRate(request.getFromCurrency(), request.getToCurrency());

        CurrencyExchangeProto.CurrencyExchangeRateResponse response = CurrencyExchangeProto.CurrencyExchangeRateResponse.newBuilder()
                .setExchangeRate(exchangeRate)
                .build();

        logger.info("Sending getExchangeRate response: fromCurrency={}, toCurrency={}, exchangeRate={}", request.getFromCurrency(), request.getToCurrency(), exchangeRate);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    /**
     * Retrieves a list of all available exchange rates.
     *
     * @param request          The empty currency exchange request.
     * @param responseObserver The stream observer to send the response back to the client.
     */
    @Override
    public void listExchangeRates(CurrencyExchangeProto.EmptyCurrencyExchange request, StreamObserver<CurrencyExchangeProto.CurrencyExchangeRateListResponse> responseObserver) {
        logger.info("Received listExchangeRates request");
        CurrencyExchangeProto.CurrencyExchangeRateListResponse.Builder responseBuilder = CurrencyExchangeProto.CurrencyExchangeRateListResponse.newBuilder();

        for (Map.Entry<String, Double> entry : exchangeRates.entrySet()) {
            String[] currencies = entry.getKey().split("_");
            CurrencyExchangeProto.CurrencyExchangeRateResponse rateResponse = CurrencyExchangeProto.CurrencyExchangeRateResponse.newBuilder()
                    .setFromCurrency(currencies[0])
                    .setToCurrency(currencies[1])
                    .setExchangeRate(entry.getValue())
                    .build();
            responseBuilder.addExchangeRates(rateResponse);
        }

        logger.info("Sending listExchangeRates response with {} exchange rates", exchangeRates.size());
        responseObserver.onNext(responseBuilder.build());
        responseObserver.onCompleted();
    }

    /**
     * Retrieves the exchange rate for a given currency pair from the defined exchange rates map.
     *
     * @param fromCurrency The currency to convert from.
     * @param toCurrency   The currency to convert to.
     * @return The exchange rate for the given currency pair.
     */
    private double getExchangeRate(String fromCurrency, String toCurrency) {
        String key = fromCurrency + "_" + toCurrency;
        double rate = exchangeRates.getOrDefault(key, 1.0); // Default exchange rate if not found
        logger.debug("Exchange rate for {} to {}: {}", fromCurrency, toCurrency, rate);
        return rate;
    }
}
