package com.example.grpcclient.rest;

import com.example.grpcclient.model.PaymentDTO;
import com.example.grpcclient.service.PaymentGrpcClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller for handling Payment related operations.
 * This controller interacts with the PaymentGrpcClient to communicate with the gRPC server.
 *
 * @author HDFC-EF
 */
@RestController
@RequestMapping("/payments")
public class PaymentController {

    @Autowired
    private PaymentGrpcClient paymentGrpcClient;

    /**
     * Retrieves a Payment by its ID.
     *
     * @param id The ID of the payment to retrieve.
     * @return The PaymentDTO object representing the payment.
     */
    @GetMapping(value = "/{id}", produces = "application/json")
    public PaymentDTO getPayment(@PathVariable int id) {
        return paymentGrpcClient.getPayment(id);
    }

    /**
     * Creates a new Payment.
     *
     * @param paymentDto The PaymentDTO object containing the payment details.
     * @return The created PaymentDTO object.
     */
    @PostMapping(consumes = "application/json", produces = "application/json")
    public PaymentDTO createPayment(@RequestBody PaymentDTO paymentDto) {
        return paymentGrpcClient.createPayment(paymentDto);
    }

    /**
     * Updates an existing Payment.
     *
     * @param paymentDto The PaymentDTO object containing the updated payment details.
     * @return The updated PaymentDTO object.
     */
    @PutMapping(consumes = "application/json", produces = "application/json")
    public PaymentDTO updatePayment(@RequestBody PaymentDTO paymentDto) {
        return paymentGrpcClient.updatePayment(paymentDto);
    }

    /**
     * Deletes a Payment by its ID.
     *
     * @param id The ID of the payment to delete.
     * @return The deleted PaymentDTO object.
     */
    @DeleteMapping(value = "/{id}", produces = "application/json")
    public PaymentDTO deletePayment(@PathVariable int id) {
        return paymentGrpcClient.deletePayment(id);
    }

    /**
     * Retrieves a list of all Payments.
     *
     * @return A list of PaymentDTO objects representing all payments.
     */
    @GetMapping(produces = "application/json")
    public List<PaymentDTO> listPayments() {
        return paymentGrpcClient.listPayments();
    }
}
