package com.example.grpcclient.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.grpcclient.model.PaymentDTO;
import com.example.grpcclient.service.PaymentGrpcClient;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    @Autowired
    private PaymentGrpcClient paymentGrpcClient;

    @GetMapping(value = "/{id}", produces = "application/json")
    public PaymentDTO getPayment(@PathVariable int id) {
        return paymentGrpcClient.getPayment(id);
    }

    @PostMapping(consumes = "application/json", produces = "application/json")
    public PaymentDTO createPayment(@RequestBody PaymentDTO paymentDto) {
        return paymentGrpcClient.createPayment(paymentDto);
    }

    @PutMapping(consumes = "application/json", produces = "application/json")
    public PaymentDTO updatePayment(@RequestBody PaymentDTO paymentDto) {
        return paymentGrpcClient.updatePayment(paymentDto);
    }

    @DeleteMapping(value = "/{id}", produces = "application/json")
    public PaymentDTO deletePayment(@PathVariable int id) {
        return paymentGrpcClient.deletePayment(id);
    }

    @GetMapping(produces = "application/json")
    public List<PaymentDTO> listPayments() {
        return paymentGrpcClient.listPayments();
    }
}
