package com.example.grpcserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpcServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
