package com.example.grpcserver.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class CurrencyExchangeRateDTOTest {

    @Test
    public void testGettersAndSetters() {
        // Create a new CurrencyExchangeRateDTO object
        CurrencyExchangeRateDTO rateDTO = new CurrencyExchangeRateDTO();

        // Set the values for the object
        rateDTO.setFromCurrency("USD");
        rateDTO.setToCurrency("EUR");
        rateDTO.setExchangeRate(0.88);

        // Assert that the getters return the correct values
        assertEquals("USD", rateDTO.getFromCurrency());
        assertEquals("EUR", rateDTO.getToCurrency());
        assertEquals(0.88, rateDTO.getExchangeRate());
    }
}
