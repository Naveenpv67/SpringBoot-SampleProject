package com.example.grpcserver.rest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.grpcserver.model.CurrencyExchangeRateDTO;
import com.example.grpcserver.model.CurrencyExchangeResponseDTO;
import com.example.grpcserver.service.CurrencyExchangeGrpcClient;

@ExtendWith(MockitoExtension.class)
public class CurrencyExchangeControllerTest {

    @InjectMocks
    private CurrencyExchangeController currencyExchangeController;

    @Mock
    private CurrencyExchangeGrpcClient currencyExchangeGrpcClient;

    @Test
    public void testExchangeCurrency() {
        String fromCurrency = "USD";
        String toCurrency = "EUR";
        double amount = 100;
        CurrencyExchangeResponseDTO expectedResponse = new CurrencyExchangeResponseDTO();
        expectedResponse.setExchangedAmount(88.0);
        expectedResponse.setFromCurrency(fromCurrency);
        expectedResponse.setToCurrency(toCurrency);
        expectedResponse.setExchangeRate(0.88);

        when(currencyExchangeGrpcClient.exchangeCurrency(fromCurrency, toCurrency, amount))
                .thenReturn(expectedResponse);

        CurrencyExchangeResponseDTO actualResponse = currencyExchangeController.exchangeCurrency(fromCurrency,
                toCurrency, amount).getBody();

        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    public void testGetExchangeRate() {
        String fromCurrency = "USD";
        String toCurrency = "EUR";
        CurrencyExchangeRateDTO expectedRate = new CurrencyExchangeRateDTO();
        expectedRate.setFromCurrency(fromCurrency);
        expectedRate.setToCurrency(toCurrency);
        expectedRate.setExchangeRate(0.88);

        when(currencyExchangeGrpcClient.getExchangeRate(fromCurrency, toCurrency)).thenReturn(expectedRate);

        CurrencyExchangeRateDTO actualRate = currencyExchangeController.getExchangeRate(fromCurrency, toCurrency).getBody();

        assertEquals(expectedRate, actualRate);
    }

    @Test
    public void testListExchangeRates() {
        CurrencyExchangeRateDTO rate1 = new CurrencyExchangeRateDTO();
        rate1.setFromCurrency("USD");
        rate1.setToCurrency("EUR");
        rate1.setExchangeRate(0.88);

        CurrencyExchangeRateDTO rate2 = new CurrencyExchangeRateDTO();
        rate2.setFromCurrency("USD");
        rate2.setToCurrency("GBP");
        rate2.setExchangeRate(0.77);

        List<CurrencyExchangeRateDTO> expectedRates = Arrays.asList(rate1, rate2);

        when(currencyExchangeGrpcClient.listExchangeRates()).thenReturn(expectedRates);

        List<CurrencyExchangeRateDTO> actualRates = currencyExchangeController.listExchangeRates().getBody();

        assertEquals(expectedRates, actualRates);
    }
}
