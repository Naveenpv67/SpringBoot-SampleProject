package com.example.grpcserver.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.grpcserver.model.CurrencyExchangeRateDTO;
import com.example.grpcserver.model.CurrencyExchangeResponseDTO;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeRateListResponse;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeRateRequest;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeRateResponse;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeRequest;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeResponse;
import com.example.protobuf.CurrencyExchangeProto.EmptyCurrencyExchange;
import com.example.protobuf.CurrencyExchangeServiceGrpc.CurrencyExchangeServiceBlockingStub;

@ExtendWith(MockitoExtension.class)
public class CurrencyExchangeGrpcClientTest {

    @InjectMocks
    private CurrencyExchangeGrpcClient currencyExchangeGrpcClient;

    @Mock
    private CurrencyExchangeServiceBlockingStub stub;

    @Test
    public void testExchangeCurrency() {
        String fromCurrency = "USD";
        String toCurrency = "EUR";
        double amount = 100;
        CurrencyExchangeResponseDTO expectedResponse = new CurrencyExchangeResponseDTO();
        expectedResponse.setExchangedAmount(88.0);
        expectedResponse.setFromCurrency(fromCurrency);
        expectedResponse.setToCurrency(toCurrency);
        expectedResponse.setExchangeRate(0.88);

        CurrencyExchangeRequest request = CurrencyExchangeRequest.newBuilder()
                .setFromCurrency(fromCurrency)
                .setToCurrency(toCurrency)
                .setAmount(amount)
                .build();
        CurrencyExchangeResponse grpcResponse = CurrencyExchangeResponse.newBuilder()
                .setExchangedAmount(88.0)
                .setFromCurrency(fromCurrency)
                .setToCurrency(toCurrency)
                .setExchangeRate(0.88)
                .build();

        when(stub.exchangeCurrency(request)).thenReturn(grpcResponse);

        CurrencyExchangeResponseDTO actualResponse = currencyExchangeGrpcClient.exchangeCurrency(fromCurrency,
                toCurrency, amount);

        assertEquals(expectedResponse.getExchangedAmount(), actualResponse.getExchangedAmount());
        assertEquals(expectedResponse.getFromCurrency(), actualResponse.getFromCurrency());
        assertEquals(expectedResponse.getToCurrency(), actualResponse.getToCurrency());
        assertEquals(expectedResponse.getExchangeRate(), actualResponse.getExchangeRate());
    }

    @Test
    public void testGetExchangeRate() {
        String fromCurrency = "USD";
        String toCurrency = "EUR";
        CurrencyExchangeRateDTO expectedRate = new CurrencyExchangeRateDTO();
        expectedRate.setFromCurrency(fromCurrency);
        expectedRate.setToCurrency(toCurrency);
        expectedRate.setExchangeRate(0.88);

        CurrencyExchangeRateRequest request = CurrencyExchangeRateRequest.newBuilder()
                .setFromCurrency(fromCurrency)
                .setToCurrency(toCurrency)
                .build();
        CurrencyExchangeRateResponse grpcResponse = CurrencyExchangeRateResponse.newBuilder()
                .setFromCurrency(fromCurrency)
                .setToCurrency(toCurrency)
                .setExchangeRate(0.88)
                .build();

        when(stub.getExchangeRate(request)).thenReturn(grpcResponse);

        CurrencyExchangeRateDTO actualRate = currencyExchangeGrpcClient.getExchangeRate(fromCurrency, toCurrency);

        assertEquals(expectedRate.getFromCurrency(), actualRate.getFromCurrency());
        assertEquals(expectedRate.getToCurrency(), actualRate.getToCurrency());
        assertEquals(expectedRate.getExchangeRate(), actualRate.getExchangeRate());
    }

    @Test
    public void testListExchangeRates() {
        CurrencyExchangeRateDTO rate1 = new CurrencyExchangeRateDTO();
        rate1.setFromCurrency("USD");
        rate1.setToCurrency("EUR");
        rate1.setExchangeRate(0.88);

        CurrencyExchangeRateDTO rate2 = new CurrencyExchangeRateDTO();
        rate2.setFromCurrency("USD");
        rate2.setToCurrency("GBP");
        rate2.setExchangeRate(0.77);

        List<CurrencyExchangeRateDTO> expectedRates = Arrays.asList(rate1, rate2);

        CurrencyExchangeRateResponse grpcResponse1 = CurrencyExchangeRateResponse.newBuilder()
                .setFromCurrency("USD")
                .setToCurrency("EUR")
                .setExchangeRate(0.88)
                .build();
        CurrencyExchangeRateResponse grpcResponse2 = CurrencyExchangeRateResponse.newBuilder()
                .setFromCurrency("USD")
                .setToCurrency("GBP")
                .setExchangeRate(0.77)
                .build();

        CurrencyExchangeRateListResponse grpcResponse = CurrencyExchangeRateListResponse.newBuilder()
                .addExchangeRates(grpcResponse1)
                .addExchangeRates(grpcResponse2)
                .build();

        when(stub.listExchangeRates(EmptyCurrencyExchange.newBuilder().build())).thenReturn(grpcResponse);

        List<CurrencyExchangeRateDTO> actualRates = currencyExchangeGrpcClient.listExchangeRates();

        assertEquals(expectedRates.size(), actualRates.size());
        for (int i = 0; i < expectedRates.size(); i++) {
            assertEquals(expectedRates.get(i).getFromCurrency(), actualRates.get(i).getFromCurrency());
            assertEquals(expectedRates.get(i).getToCurrency(), actualRates.get(i).getToCurrency());
            assertEquals(expectedRates.get(i).getExchangeRate(), actualRates.get(i).getExchangeRate());
        }
    }
}
