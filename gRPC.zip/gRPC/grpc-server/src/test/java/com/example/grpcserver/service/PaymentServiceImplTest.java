package com.example.grpcserver.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.example.protobuf.PaymentProto.EmptyPayment;
import com.example.protobuf.PaymentProto.Payment;
import com.example.protobuf.PaymentProto.PaymentRequest;
import com.google.common.collect.Lists;
import com.google.protobuf.Empty;

import io.grpc.stub.StreamObserver;

@ExtendWith(MockitoExtension.class)
public class PaymentServiceImplTest {

    @InjectMocks
    private PaymentServiceImpl paymentService;

    @Mock
    private StreamObserver<Empty> responseObserver;

    @Test
    public void testGetPayment() {
        Payment payment = Payment.newBuilder().setId(1).setAmount(100.0).build();
        paymentService.paymentDatabase.put(1, payment);

        PaymentRequest request = PaymentRequest.newBuilder().setId(1).build();
        StreamObserver<com.example.protobuf.PaymentProto.PaymentResponse> responseObserver = new StreamObserver<com.example.protobuf.PaymentProto.PaymentResponse>() {
            @Override
            public void onNext(com.example.protobuf.PaymentProto.PaymentResponse value) {
                assertEquals(payment, value.getPayment());
            }

            @Override
            public void onError(Throwable t) {

            }

            @Override
            public void onCompleted() {

            }
        };

        paymentService.getPayment(request, responseObserver);
    }

    @Test
    public void testCreatePayment() {
        Payment payment = Payment.newBuilder().setId(1).setAmount(100.0).build();
        StreamObserver<com.example.protobuf.PaymentProto.PaymentResponse> responseObserver = new StreamObserver<com.example.protobuf.PaymentProto.PaymentResponse>() {
            @Override
            public void onNext(com.example.protobuf.PaymentProto.PaymentResponse value) {
                assertEquals(payment, value.getPayment());
            }

            @Override
            public void onError(Throwable t) {

            }

            @Override
            public void onCompleted() {

            }
        };

        paymentService.createPayment(payment, responseObserver);

        // Retrieve the payment from the database
        Payment storedPayment = paymentService.paymentDatabase.get(1);

        // Assert that the fields are equal
        assertEquals(payment.getId(), storedPayment.getId());
        assertEquals(payment.getAmount(), storedPayment.getAmount(), 0.001); // Use delta for double comparison
    }


    @Test
    public void testUpdatePayment() {
        Payment payment = Payment.newBuilder().setId(1).setAmount(100.0).build();
        paymentService.paymentDatabase.put(1, payment);

        Payment updatedPayment = Payment.newBuilder().setId(1).setAmount(200.0).build();
        StreamObserver<com.example.protobuf.PaymentProto.PaymentResponse> responseObserver = new StreamObserver<com.example.protobuf.PaymentProto.PaymentResponse>() {
            @Override
            public void onNext(com.example.protobuf.PaymentProto.PaymentResponse value) {
                assertEquals(updatedPayment, value.getPayment());
            }

            @Override
            public void onError(Throwable t) {

            }

            @Override
            public void onCompleted() {

            }
        };

        paymentService.updatePayment(updatedPayment, responseObserver);
        assertEquals(updatedPayment, paymentService.paymentDatabase.get(1));
    }

    @Test
    public void testDeletePayment() {
        Payment payment = Payment.newBuilder().setId(1).setAmount(100.0).build();
        paymentService.paymentDatabase.put(1, payment);

        PaymentRequest request = PaymentRequest.newBuilder().setId(1).build();
        StreamObserver<com.example.protobuf.PaymentProto.PaymentResponse> responseObserver = new StreamObserver<com.example.protobuf.PaymentProto.PaymentResponse>() {
            @Override
            public void onNext(com.example.protobuf.PaymentProto.PaymentResponse value) {
                assertEquals(payment, value.getPayment());
            }

            @Override
            public void onError(Throwable t) {

            }

            @Override
            public void onCompleted() {

            }
        };

        paymentService.deletePayment(request, responseObserver);
        assertEquals(0, paymentService.paymentDatabase.size());
    }

    @Test
    public void testListPayments() {
        Payment payment1 = Payment.newBuilder().setId(1).setAmount(100.0).build();
        Payment payment2 = Payment.newBuilder().setId(2).setAmount(200.0).build();
        paymentService.paymentDatabase.put(1, payment1);
        paymentService.paymentDatabase.put(2, payment2);

        EmptyPayment request = EmptyPayment.newBuilder().build();
        StreamObserver<com.example.protobuf.PaymentProto.PaymentListResponse> responseObserver = new StreamObserver<com.example.protobuf.PaymentProto.PaymentListResponse>() {
            @Override
            public void onNext(com.example.protobuf.PaymentProto.PaymentListResponse value) {
                assertEquals(Lists.newArrayList(payment1, payment2), value.getPaymentsList());
            }

            @Override
            public void onError(Throwable t) {

            }

            @Override
            public void onCompleted() {

            }
        };

        paymentService.listPayments(request, responseObserver);
    }
}
