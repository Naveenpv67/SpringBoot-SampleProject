package com.example.grpcserver.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class CurrencyExchangeResponseDTOTest {

    @Test
    public void testGettersAndSetters() {
        // Create a new CurrencyExchangeResponseDTO object
        CurrencyExchangeResponseDTO responseDTO = new CurrencyExchangeResponseDTO();

        // Set the values for the object
        responseDTO.setExchangedAmount(88.0);
        responseDTO.setFromCurrency("USD");
        responseDTO.setToCurrency("EUR");
        responseDTO.setExchangeRate(0.88);

        // Assert that the getters return the correct values
        assertEquals(88.0, responseDTO.getExchangedAmount());
        assertEquals("USD", responseDTO.getFromCurrency());
        assertEquals("EUR", responseDTO.getToCurrency());
        assertEquals(0.88, responseDTO.getExchangeRate());
    }
}
