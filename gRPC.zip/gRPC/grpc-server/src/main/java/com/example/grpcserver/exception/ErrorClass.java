package com.example.grpcserver.exception;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Represents an error response.
 */
@Data
@AllArgsConstructor
public class ErrorClass {
    private int status;
    private String message;
}
