package com.example.grpcserver.exception.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.grpcserver.exception.CustomGrpcClientException;
import com.example.grpcserver.exception.ErrorClass;

/**
 * Global exception handler for the Currency Exchange REST controller.
 *
 * @author HDFC-EF
 */
@RestControllerAdvice
class CurrencyExchangeControllerAdvice {

    /**
     * Handles {@link CustomGrpcClientException} and returns an HTTP error response.
     *
     * @param ex The exception that was thrown.
     * @return A {@link ResponseEntity} with an appropriate HTTP status and error message.
     */
    @ExceptionHandler(CustomGrpcClientException.class)
    public ResponseEntity<ErrorClass> handleCustomGrpcClientException(CustomGrpcClientException ex) {
        HttpStatus status = mapGrpcStatusToHttpStatus(ex.getStatusCode());
        ErrorClass error = new ErrorClass(status.value(), ex.getMessage());
        return ResponseEntity.status(status).body(error);
    }

    /**
     * Maps gRPC status codes to appropriate HTTP status codes.
     *
     * @param grpcStatusCode The gRPC status code.
     * @return The corresponding HTTP status code.
     */
    private HttpStatus mapGrpcStatusToHttpStatus(int grpcStatusCode) {
        // Simplified mapping - you might need to add more cases
        if (grpcStatusCode == 5) { // gRPC NOT_FOUND
            return HttpStatus.NOT_FOUND;
        } else if (grpcStatusCode == 3) { // gRPC INVALID_ARGUMENT
            return HttpStatus.BAD_REQUEST;
        } else if (grpcStatusCode == 14) { // gRPC UNAVAILABLE
            return HttpStatus.SERVICE_UNAVAILABLE;
        } else {
            return HttpStatus.INTERNAL_SERVER_ERROR;
        }
    }
}
