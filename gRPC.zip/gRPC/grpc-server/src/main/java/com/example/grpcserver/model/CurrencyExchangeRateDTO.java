package com.example.grpcserver.model;

import lombok.Data;

@Data
public class CurrencyExchangeRateDTO {
   
    private String fromCurrency;
    private String toCurrency;
    private double exchangeRate;
}
