package com.example.grpcserver.model;

import lombok.Data;

/**
 * Data Transfer Object representing the exchange rate between two currencies.
 *
 * @author HDFC-EF
 */
@Data
public class CurrencyExchangeRateDTO {

    /**
     * The original currency code (e.g., "USD").
     */
    private String fromCurrency;

    /**
     * The target currency code (e.g., "EUR").
     */
    private String toCurrency;

    /**
     * The exchange rate from fromCurrency to toCurrency.
     */
    private double exchangeRate;
}
