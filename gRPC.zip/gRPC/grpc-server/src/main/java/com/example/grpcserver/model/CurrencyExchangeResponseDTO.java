package com.example.grpcserver.model;

import lombok.Data;

@Data
public class CurrencyExchangeResponseDTO {

    private double exchangedAmount;
    private String fromCurrency;
    private String toCurrency;
    private double exchangeRate;
}
