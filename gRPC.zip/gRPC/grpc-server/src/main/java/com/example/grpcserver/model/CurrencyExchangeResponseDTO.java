package com.example.grpcserver.model;

import lombok.Data;

/**
 * Data Transfer Object representing the response of a currency exchange request.
 *
 * @author HDFC-EF
 */
@Data
public class CurrencyExchangeResponseDTO {

    /**
     * The exchanged amount in the target currency.
     */
    private double exchangedAmount;

    /**
     * The original currency code (e.g., "USD").
     */
    private String fromCurrency;

    /**
     * The target currency code (e.g., "EUR").
     */
    private String toCurrency;

    /**
     * The exchange rate used for the conversion.
     */
    private double exchangeRate;
}
