package com.example.grpcserver.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.grpcserver.model.CurrencyExchangeRateDTO;
import com.example.grpcserver.model.CurrencyExchangeResponseDTO;
import com.example.grpcserver.service.CurrencyExchangeGrpcClient;

@RestController
@RequestMapping("/currency-exchange")
public class CurrencyExchangeController {

    @Autowired
    private CurrencyExchangeGrpcClient currencyExchangeGrpcClient;

    @GetMapping(value = "/exchange/{fromCurrency}/{toCurrency}/{amount}", produces = "application/json")
    public CurrencyExchangeResponseDTO exchangeCurrency(@PathVariable String fromCurrency, @PathVariable String toCurrency, @PathVariable double amount) {
        return currencyExchangeGrpcClient.exchangeCurrency(fromCurrency, toCurrency, amount);
    }

    @GetMapping(value = "/rate/{fromCurrency}/{toCurrency}", produces = "application/json")
    public CurrencyExchangeRateDTO getExchangeRate(@PathVariable String fromCurrency, @PathVariable String toCurrency) {
        return currencyExchangeGrpcClient.getExchangeRate(fromCurrency, toCurrency);
    }

    @GetMapping(value = "/rates", produces = "application/json")
    public List<CurrencyExchangeRateDTO> listExchangeRates() {
        return currencyExchangeGrpcClient.listExchangeRates();
    }
}
