package com.example.grpcserver.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.grpcserver.exception.CustomGrpcClientException;
import com.example.grpcserver.exception.ErrorClass;
import com.example.grpcserver.model.CurrencyExchangeRateDTO;
import com.example.grpcserver.model.CurrencyExchangeResponseDTO;
import com.example.grpcserver.service.CurrencyExchangeGrpcClient;

/**
 * REST Controller for currency exchange operations.
 * This controller interacts with the gRPC client to perform currency exchange.
 *
 * @author HDFC-EF
 */
@RestController
@RequestMapping("/currency-exchange")
public class CurrencyExchangeController {

    @Autowired
    private CurrencyExchangeGrpcClient currencyExchangeGrpcClient;

    /**
     * Endpoint to exchange currency.
     *
     * @param fromCurrency The original currency code (e.g., "USD").
     * @param toCurrency   The target currency code (e.g., "EUR").
     * @param amount       The amount to exchange.
     * @return CurrencyExchangeResponseDTO containing the exchanged amount, currencies, and exchange rate.
     */
    @GetMapping(value = "/exchange/{fromCurrency}/{toCurrency}/{amount}", produces = "application/json")
    public ResponseEntity<CurrencyExchangeResponseDTO> exchangeCurrency(@PathVariable String fromCurrency, @PathVariable String toCurrency, @PathVariable double amount) {
        return ResponseEntity.ok(currencyExchangeGrpcClient.exchangeCurrency(fromCurrency, toCurrency, amount));
    }

    /**
     * Endpoint to get the exchange rate between two currencies.
     *
     * @param fromCurrency The original currency code (e.g., "USD").
     * @param toCurrency   The target currency code (e.g., "EUR").
     * @return CurrencyExchangeRateDTO containing the exchange rate between the currencies.
     */
    @GetMapping(value = "/rate/{fromCurrency}/{toCurrency}", produces = "application/json")
    public ResponseEntity<CurrencyExchangeRateDTO> getExchangeRate(@PathVariable String fromCurrency, @PathVariable String toCurrency) {
        return ResponseEntity.ok(currencyExchangeGrpcClient.getExchangeRate(fromCurrency, toCurrency));
    }

    /**
     * Endpoint to get a list of all available exchange rates.
     *
     * @return List of CurrencyExchangeRateDTO objects, each representing an exchange rate.
     */
    @GetMapping(value = "/rates", produces = "application/json")
    public ResponseEntity<List<CurrencyExchangeRateDTO>> listExchangeRates() {
        return ResponseEntity.ok(currencyExchangeGrpcClient.listExchangeRates());
    }

}
