package com.example.grpcserver.service;

import java.util.HashMap;
import java.util.Map;

import com.example.protobuf.PaymentProto.Empty;
import com.example.protobuf.PaymentProto.Payment;
import com.example.protobuf.PaymentProto.PaymentListResponse;
import com.example.protobuf.PaymentProto.PaymentRequest;
import com.example.protobuf.PaymentProto.PaymentResponse;
import com.example.protobuf.PaymentServiceGrpc;

import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;

@GrpcService
public class PaymentServiceImpl extends PaymentServiceGrpc.PaymentServiceImplBase {

    private final Map<Integer, Payment> paymentDatabase = new HashMap<>();

    @Override
    public void getPayment(PaymentRequest request, StreamObserver<PaymentResponse> responseObserver) {
        Payment payment = paymentDatabase.get(request.getId());
        PaymentResponse response = PaymentResponse.newBuilder().setPayment(payment).build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void createPayment(Payment request, StreamObserver<PaymentResponse> responseObserver) {
        paymentDatabase.put(request.getId(), request);
        PaymentResponse response = PaymentResponse.newBuilder().setPayment(request).build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void updatePayment(Payment request, StreamObserver<PaymentResponse> responseObserver) {
        paymentDatabase.put(request.getId(), request);
        PaymentResponse response = PaymentResponse.newBuilder().setPayment(request).build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void deletePayment(PaymentRequest request, StreamObserver<PaymentResponse> responseObserver) {
        Payment payment = paymentDatabase.remove(request.getId());
        PaymentResponse response = PaymentResponse.newBuilder().setPayment(payment).build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void listPayments(Empty request, StreamObserver<PaymentListResponse> responseObserver) {
        PaymentListResponse response = PaymentListResponse.newBuilder()
                .addAllPayments(paymentDatabase.values())
                .build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }
}
