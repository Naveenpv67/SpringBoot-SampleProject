package com.example.grpcserver.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.example.protobuf.PaymentProto.EmptyPayment;
import com.example.protobuf.PaymentProto.Payment;
import com.example.protobuf.PaymentProto.PaymentListResponse;
import com.example.protobuf.PaymentProto.PaymentRequest;
import com.example.protobuf.PaymentProto.PaymentResponse;
import com.example.protobuf.PaymentServiceGrpc;

import io.grpc.stub.StreamObserver;
import net.devh.boot.grpc.server.service.GrpcService;

/**
 * gRPC service implementation for managing payments.
 *
 * @author HDFC-EF
 */
@GrpcService
public class PaymentServiceImpl extends PaymentServiceGrpc.PaymentServiceImplBase {

    private static final Logger logger = LoggerFactory.getLogger(PaymentServiceImpl.class);
    final Map<Integer, Payment> paymentDatabase = new HashMap<>();

    /**
     * Retrieves a payment by ID.
     *
     * @param request          The request containing the payment ID.
     * @param responseObserver The observer to send the response to.
     */
    @Override
    public void getPayment(PaymentRequest request, StreamObserver<PaymentResponse> responseObserver) {
        logger.info("Received getPayment request: id={}", request.getId());
        Payment payment = paymentDatabase.get(request.getId());
        PaymentResponse response = PaymentResponse.newBuilder().setPayment(payment).build();
        logger.info("Sending getPayment response: {}", response);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    /**
     * Creates a new payment.
     *
     * @param request          The request containing the payment details.
     * @param responseObserver The observer to send the response to.
     */
    @Override
    public void createPayment(Payment request, StreamObserver<PaymentResponse> responseObserver) {
        logger.info("Received createPayment request: {}", request);
        paymentDatabase.put(request.getId(), request);
        PaymentResponse response = PaymentResponse.newBuilder().setPayment(request).build();
        logger.info("Sending createPayment response: {}", response);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    /**
     * Updates an existing payment.
     *
     * @param request          The request containing the updated payment details.
     * @param responseObserver The observer to send the response to.
     */
    @Override
    public void updatePayment(Payment request, StreamObserver<PaymentResponse> responseObserver) {
        logger.info("Received updatePayment request: {}", request);
        paymentDatabase.put(request.getId(), request);
        PaymentResponse response = PaymentResponse.newBuilder().setPayment(request).build();
        logger.info("Sending updatePayment response: {}", response);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    /**
     * Deletes a payment by ID.
     *
     * @param request          The request containing the payment ID.
     * @param responseObserver The observer to send the response to.
     */
    @Override
    public void deletePayment(PaymentRequest request, StreamObserver<PaymentResponse> responseObserver) {
        logger.info("Received deletePayment request: id={}", request.getId());
        Payment payment = paymentDatabase.remove(request.getId());
        PaymentResponse response = PaymentResponse.newBuilder().setPayment(payment).build();
        logger.info("Sending deletePayment response: {}", response);
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    /**
     * Retrieves a list of all payments.
     *
     * @param request          An empty request.
     * @param responseObserver The observer to send the response to.
     */
    @Override
    public void listPayments(EmptyPayment request, StreamObserver<PaymentListResponse> responseObserver) {
        logger.info("Received listPayments request");
        PaymentListResponse response = PaymentListResponse.newBuilder()
                .addAllPayments(paymentDatabase.values())
                .build();
        logger.info("Sending listPayments response with {} payments", paymentDatabase.size());
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }
}
