package com.example.grpcserver.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.example.grpcserver.exception.CustomGrpcClientException;
import com.example.grpcserver.model.CurrencyExchangeRateDTO;
import com.example.grpcserver.model.CurrencyExchangeResponseDTO;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeRateListResponse;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeRateRequest;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeRateResponse;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeRequest;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeResponse;
import com.example.protobuf.CurrencyExchangeProto.EmptyCurrencyExchange;
import com.example.protobuf.CurrencyExchangeServiceGrpc;

import io.grpc.StatusRuntimeException;
import net.devh.boot.grpc.client.inject.GrpcClient;

/**
 * gRPC client for interacting with the Currency Exchange service.
 *
 * @author HDFC-EF
 */
@Component
public class CurrencyExchangeGrpcClient {

    @GrpcClient("currencyExchangeService")
    private CurrencyExchangeServiceGrpc.CurrencyExchangeServiceBlockingStub stub;

    /**
     * Exchanges currency using the gRPC service.
     *
     * @param fromCurrency The original currency code (e.g., "USD").
     * @param toCurrency   The target currency code (e.g., "EUR").
     * @param amount       The amount to exchange.
     * @return CurrencyExchangeResponseDTO containing the exchanged amount, currencies, and exchange rate.
     * @throws CustomGrpcClientException if there is an error during the gRPC call.
     */
    public CurrencyExchangeResponseDTO exchangeCurrency(String fromCurrency, String toCurrency, double amount) {
        try {
            CurrencyExchangeRequest request = CurrencyExchangeRequest.newBuilder()
                    .setFromCurrency(fromCurrency)
                    .setToCurrency(toCurrency)
                    .setAmount(amount)
                    .build();
            CurrencyExchangeResponse response = stub.exchangeCurrency(request);
            return convertToDTO(response);
        } catch (StatusRuntimeException ex) {
            int statusCode = ex.getStatus().getCode().value();
            throw new CustomGrpcClientException("Error calling exchangeCurrency gRPC method", statusCode);
        } catch (Exception ex) {
            // Handle or wrap other exceptions as CustomGrpcClientException
            throw new CustomGrpcClientException("Unexpected error during currency exchange", 500);
        }
    }

    /**
     * Retrieves the exchange rate between two currencies from the gRPC service.
     *
     * @param fromCurrency The original currency code (e.g., "USD").
     * @param toCurrency   The target currency code (e.g., "EUR").
     * @return CurrencyExchangeRateDTO containing the exchange rate between the currencies.
     * @throws CustomGrpcClientException if there is an error during the gRPC call.
     */
    public CurrencyExchangeRateDTO getExchangeRate(String fromCurrency, String toCurrency) {
        try {
            CurrencyExchangeRateRequest request = CurrencyExchangeRateRequest.newBuilder()
                    .setFromCurrency(fromCurrency)
                    .setToCurrency(toCurrency)
                    .build();
            CurrencyExchangeRateResponse response = stub.getExchangeRate(request);
            return convertToDTO(response);
        } catch (StatusRuntimeException ex) {
            int statusCode = ex.getStatus().getCode().value();
            throw new CustomGrpcClientException("Error calling getExchangeRate gRPC method", statusCode);
        } catch (Exception ex) {
            // Handle or wrap other exceptions as CustomGrpcClientException
            throw new CustomGrpcClientException("Unexpected error getting exchange rate", 500);
        }
    }

    /**
     * Retrieves a list of all available exchange rates from the gRPC service.
     *
     * @return List of CurrencyExchangeRateDTO objects, each representing an exchange rate.
     * @throws CustomGrpcClientException if there is an error during the gRPC call.
     */
    public List<CurrencyExchangeRateDTO> listExchangeRates() {
        try {
            EmptyCurrencyExchange request = EmptyCurrencyExchange.newBuilder().build();
            CurrencyExchangeRateListResponse response = stub.listExchangeRates(request);
            return response.getExchangeRatesList().stream()
                    .map(this::convertToDTO)
                    .collect(Collectors.toList());
        } catch (StatusRuntimeException ex) {
            int statusCode = ex.getStatus().getCode().value();
            throw new CustomGrpcClientException("Error calling listExchangeRates gRPC method", statusCode);
        } catch (Exception ex) {
            // Handle or wrap other exceptions as CustomGrpcClientException
            throw new CustomGrpcClientException("Unexpected error listing exchange rates", 500);
        }
    }

    /**
     * Converts a {@link CurrencyExchangeResponse} to a {@link CurrencyExchangeResponseDTO}.
     *
     * @param response The gRPC response object.
     * @return The equivalent DTO object.
     */
    private CurrencyExchangeResponseDTO convertToDTO(CurrencyExchangeResponse response) {
        CurrencyExchangeResponseDTO dto = new CurrencyExchangeResponseDTO();
        dto.setExchangedAmount(response.getExchangedAmount());
        dto.setFromCurrency(response.getFromCurrency());
        dto.setToCurrency(response.getToCurrency());
        dto.setExchangeRate(response.getExchangeRate());
        return dto;
    }

    /**
     * Converts a {@link CurrencyExchangeRateResponse} to a {@link CurrencyExchangeRateDTO}.
     *
     * @param response The gRPC response object.
     * @return The equivalent DTO object.
     */
    private CurrencyExchangeRateDTO convertToDTO(CurrencyExchangeRateResponse response) {
        CurrencyExchangeRateDTO dto = new CurrencyExchangeRateDTO();
        dto.setFromCurrency(response.getFromCurrency());
        dto.setToCurrency(response.getToCurrency());
        dto.setExchangeRate(response.getExchangeRate());
        return dto;
    }
}
