package com.example.grpcserver.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.example.grpcserver.model.CurrencyExchangeRateDTO;
import com.example.grpcserver.model.CurrencyExchangeResponseDTO;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeRateListResponse;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeRateRequest;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeRateResponse;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeRequest;
import com.example.protobuf.CurrencyExchangeProto.CurrencyExchangeResponse;
import com.example.protobuf.CurrencyExchangeProto.EmptyCurrencyExchange;
import com.example.protobuf.CurrencyExchangeServiceGrpc;

import net.devh.boot.grpc.client.inject.GrpcClient;

@Component
public class CurrencyExchangeGrpcClient {

    @GrpcClient("currencyExchangeService")
    private CurrencyExchangeServiceGrpc.CurrencyExchangeServiceBlockingStub stub;

    public CurrencyExchangeResponseDTO exchangeCurrency(String fromCurrency, String toCurrency, double amount) {
        CurrencyExchangeRequest request = CurrencyExchangeRequest.newBuilder()
                .setFromCurrency(fromCurrency)
                .setToCurrency(toCurrency)
                .setAmount(amount)
                .build();
        CurrencyExchangeResponse response = stub.exchangeCurrency(request);
        return convertToDTO(response);
    }

    public CurrencyExchangeRateDTO getExchangeRate(String fromCurrency, String toCurrency) {
        CurrencyExchangeRateRequest request = CurrencyExchangeRateRequest.newBuilder()
                .setFromCurrency(fromCurrency)
                .setToCurrency(toCurrency)
                .build();
        CurrencyExchangeRateResponse response = stub.getExchangeRate(request);
        return convertToDTO(response);
    }

    public List<CurrencyExchangeRateDTO> listExchangeRates() {
        EmptyCurrencyExchange request = EmptyCurrencyExchange.newBuilder().build();
        CurrencyExchangeRateListResponse response = stub.listExchangeRates(request);
        return response.getExchangeRatesList().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    private CurrencyExchangeResponseDTO convertToDTO(CurrencyExchangeResponse response) {
        CurrencyExchangeResponseDTO dto = new CurrencyExchangeResponseDTO();
        dto.setExchangedAmount(response.getExchangedAmount());
        dto.setFromCurrency(response.getFromCurrency());
        dto.setToCurrency(response.getToCurrency());
        dto.setExchangeRate(response.getExchangeRate());
        return dto;
    }

    private CurrencyExchangeRateDTO convertToDTO(CurrencyExchangeRateResponse response) {
        CurrencyExchangeRateDTO dto = new CurrencyExchangeRateDTO();
        dto.setFromCurrency(response.getFromCurrency());
        dto.setToCurrency(response.getToCurrency());
        dto.setExchangeRate(response.getExchangeRate());
        return dto;
    }
}
