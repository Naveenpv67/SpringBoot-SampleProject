package com.example.grpcserver.exception;

/**
 * Custom exception class for gRPC client errors.
 *
 * @author HDFC-EF
 */
public class CustomGrpcClientException extends RuntimeException {

    private final int statusCode; // Add status code field

    /**
     * Constructs a new runtime exception with the specified detail message and status code.
     *
     * @param message    The detail message (the error description).
     * @param statusCode The HTTP status code associated with the exception.
     */
    public CustomGrpcClientException(String message, int statusCode) {
        super(message);
        this.statusCode = statusCode;
    }

    /**
     * Returns the HTTP status code associated with the exception.
     *
     * @return The HTTP status code.
     */
    public int getStatusCode() {
        return statusCode;
    }
}
