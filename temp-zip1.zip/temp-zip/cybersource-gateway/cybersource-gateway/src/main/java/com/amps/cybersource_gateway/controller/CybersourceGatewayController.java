package com.amps.cybersource_gateway.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.amps.cybersource_gateway.model.PaymentRequest;
import com.amps.cybersource_gateway.model.PaymentResponse;

@RestController
public class CybersourceGatewayController {
    private static final Logger logger = LoggerFactory.getLogger(CybersourceGatewayController.class);

    @PostMapping("/processPayment")
    public PaymentResponse processPayment(@RequestBody PaymentRequest request) {
        logger.info("Cybersource Gateway received payment request: userId={}, amount={}", request.getUserId(), request.getAmount());

        // Mock response
        PaymentResponse response = new PaymentResponse();
        response.setStatus("SUCCESS");
        response.setTransactionId("CS123456");

        logger.info("Cybersource Gateway sending payment response: status={}, transactionId={}", response.getStatus(), response.getTransactionId());
        return response;
    }
}
