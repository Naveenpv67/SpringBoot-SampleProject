package com.amps.migs_gateway.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.amps.migs_gateway.model.PaymentRequest;
import com.amps.migs_gateway.model.PaymentResponse;

@RestController
public class MIGSGatewayController {
    private static final Logger logger = LoggerFactory.getLogger(MIGSGatewayController.class);

    @PostMapping("/processPayment")
    public PaymentResponse processPayment(@RequestBody PaymentRequest request) {
        logger.info("MIGS Gateway received payment request: userId={}, amount={}", request.getUserId(), request.getAmount());

        // Mock response
        PaymentResponse response = new PaymentResponse();
        response.setStatus("SUCCESS");
        response.setTransactionId("MIGS123456");

        logger.info("MIGS Gateway sending payment response: status={}, transactionId={}", response.getStatus(), response.getTransactionId());
        return response;
    }
}
