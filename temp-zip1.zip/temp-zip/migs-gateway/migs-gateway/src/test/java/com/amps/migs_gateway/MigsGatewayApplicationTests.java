package com.amps.migs_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MigsGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
