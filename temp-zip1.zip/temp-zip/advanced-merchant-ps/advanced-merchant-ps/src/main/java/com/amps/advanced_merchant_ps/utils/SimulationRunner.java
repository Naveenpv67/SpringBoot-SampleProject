package com.amps.advanced_merchant_ps.utils;

import com.amps.advanced_merchant_ps.service.AmpsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class SimulationRunner implements CommandLineRunner {

    private final AmpsService ampsService;

    @Autowired
    public SimulationRunner(AmpsService ampsService) {
        this.ampsService = ampsService;
    }

    @Override
    public void run(String... args) {
        // Simulate 100 payment requests
        ampsService.simulateRequests(1000);
    }
}
