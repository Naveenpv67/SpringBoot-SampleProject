package com.amps.advanced_merchant_ps.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.amps.advanced_merchant_ps.balancer.WeightedRoundRobinBalancer;
import com.amps.advanced_merchant_ps.config.PaymentGatewayConfig;
import com.amps.advanced_merchant_ps.model.Gateway;
import com.amps.advanced_merchant_ps.model.PaymentRequest;
import com.amps.advanced_merchant_ps.model.PaymentResponse;

@Service
public class AmpsService {

    private static final Logger logger = LoggerFactory.getLogger(AmpsService.class);
    private final WebClient webClient;
    private final WeightedRoundRobinBalancer balancer;

    @Autowired
    public AmpsService(WebClient.Builder webClientBuilder, PaymentGatewayConfig gatewayConfig) {
        List<Gateway> gateways = gatewayConfig.getGateways();
        if (gateways == null || gateways.isEmpty()) {
            throw new IllegalStateException("Gateways configuration is not loaded correctly.");
        }
        this.balancer = new WeightedRoundRobinBalancer(gateways);
        this.webClient = webClientBuilder.build();
    }

    public PaymentResponse routePayment(PaymentRequest request) {
        Gateway gateway = balancer.getNextGateway();
        logger.info("Routing payment request for userId: {} to gateway: {}", request.getUserId(), gateway.getName());
        logger.info("Gateway details: Name={}, Weight={}", gateway.getName(), gateway.getWeight());

        String url = gateway.getUrl() + "/processPayment";
        logger.info("Constructed URL: {}", url);

        try {
            PaymentResponse response = webClient.post()
                    .uri(url)
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(PaymentResponse.class)
                    .doOnNext(resp -> logger.info("Received response from gateway {}: {}", gateway.getName(), resp))
                    .doOnError(e -> logger.error("Error processing payment with gateway {}: {}", gateway.getName(), e.getMessage(), e))
                    .block();

            return response;
        } catch (Exception e) {
            logger.error("Exception occurred: {}", e.getMessage(), e);
            return null;
        }
    }
    
    public Gateway routePaymentForTesting(PaymentRequest request) {
        Gateway gateway = balancer.getNextGateway();
        logger.info("Routing payment request for userId: {} to gateway: {}", request.getUserId(), gateway.getName());
        logger.info("Gateway details: Name={}, Weight={}", gateway.getName(), gateway.getWeight());

        String url = gateway.getUrl() + "/processPayment";
        logger.info("Constructed URL: {}", url);

        try {
            PaymentResponse response = webClient.post()
                    .uri(url)
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(PaymentResponse.class)
                    .doOnNext(resp -> logger.info("Received response from gateway {}: {}", gateway.getName(), resp))
                    .doOnError(e -> logger.error("Error processing payment with gateway {}: {}", gateway.getName(), e.getMessage(), e))
                    .block();

            return gateway;
        } catch (Exception e) {
            logger.error("Exception occurred: {}", e.getMessage(), e);
            return null;
        }
    }

    public void simulateRequests(int numberOfRequests) {
        Map<String, Integer> gatewayRequestCount = new HashMap<>();

        for (int i = 0; i < numberOfRequests; i++) {
            PaymentRequest request = new PaymentRequest("123", 101); // Create a mock request
            Gateway gateway = routePaymentForTesting(request);
            gatewayRequestCount.put(gateway.getName(), gatewayRequestCount.getOrDefault(gateway.getName(), 0) + 1);
        }

        // Log the distribution of requests
        gatewayRequestCount.forEach((gatewayName, count) -> 
            logger.info("Gateway {} handled {} requests out of {}", gatewayName, count, numberOfRequests)
        );
    }
}
