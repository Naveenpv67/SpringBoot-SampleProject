package com.amps.advanced_merchant_ps.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amps.advanced_merchant_ps.model.PaymentRequest;
import com.amps.advanced_merchant_ps.model.PaymentResponse;
import com.amps.advanced_merchant_ps.service.AmpsService;

@RestController
@RequestMapping("/amps")
public class AmpsController {

    private static final Logger logger = LoggerFactory.getLogger(AmpsController.class);
    private final AmpsService ampsService;

    @Autowired
    public AmpsController(AmpsService ampsService) {
        this.ampsService = ampsService;
    }

    @PostMapping("/process")
    public PaymentResponse processPayment(@RequestBody PaymentRequest request) {
        logger.info("Received payment request for userId: {}", request.getUserId());

        // Route the payment request using AmpsService
        PaymentResponse response = ampsService.routePayment(request);

        // Log the response or error if processing fails
        if (response != null) {
            logger.info("Successfully routed payment request for userId: {} to gateway. Response: {}", request.getUserId(), response);
        } else {
            logger.error("Failed to route payment request for userId: {}", request.getUserId());
        }

        return response;
    }
}
