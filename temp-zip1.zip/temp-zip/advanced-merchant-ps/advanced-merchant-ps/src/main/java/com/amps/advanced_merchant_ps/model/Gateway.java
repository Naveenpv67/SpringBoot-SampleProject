package com.amps.advanced_merchant_ps.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Gateway {
	private String name;
	private int weight;
	private String url;

}