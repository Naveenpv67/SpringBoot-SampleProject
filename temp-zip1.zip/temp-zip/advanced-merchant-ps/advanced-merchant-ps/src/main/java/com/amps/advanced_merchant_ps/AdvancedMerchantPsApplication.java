package com.amps.advanced_merchant_ps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvancedMerchantPsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdvancedMerchantPsApplication.class, args);
	}

}
