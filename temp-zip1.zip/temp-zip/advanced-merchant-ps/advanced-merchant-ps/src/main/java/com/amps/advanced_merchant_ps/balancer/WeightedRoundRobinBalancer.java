package com.amps.advanced_merchant_ps.balancer;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.amps.advanced_merchant_ps.model.Gateway;

public class WeightedRoundRobinBalancer {

    private static final Logger logger = LoggerFactory.getLogger(WeightedRoundRobinBalancer.class);

    private final List<Gateway> gateways;
    private final int[] cumulativeWeights;
    private final int totalWeight;
    private int currentIndex;
    private final Random random;

    public WeightedRoundRobinBalancer(List<Gateway> gateways) {
        if (gateways == null || gateways.isEmpty()) {
            throw new IllegalArgumentException("Gateways list cannot be null or empty");
        }
        this.gateways = new ArrayList<>(gateways);
        this.totalWeight = calculateTotalWeight(gateways);
        this.cumulativeWeights = calculateCumulativeWeights(gateways);
        this.currentIndex = 0;
        this.random = new Random();
    }

    private int calculateTotalWeight(List<Gateway> gateways) {
        int totalWeight = 0;
        for (Gateway gateway : gateways) {
            totalWeight += gateway.getWeight();
        }
        return totalWeight;
    }

    private int[] calculateCumulativeWeights(List<Gateway> gateways) {
        int[] cumulativeWeights = new int[gateways.size()];
        cumulativeWeights[0] = gateways.get(0).getWeight();
        for (int i = 1; i < gateways.size(); i++) {
            cumulativeWeights[i] = cumulativeWeights[i - 1] + gateways.get(i).getWeight();
        }
        return cumulativeWeights;
    }

    public Gateway getNextGateway() {
        int randomValue = random.nextInt(totalWeight);
        for (int i = 0; i < cumulativeWeights.length; i++) {
            if (randomValue < cumulativeWeights[i]) {
                currentIndex = i;
                break;
            }
        }
        return gateways.get(currentIndex);
    }
}
		