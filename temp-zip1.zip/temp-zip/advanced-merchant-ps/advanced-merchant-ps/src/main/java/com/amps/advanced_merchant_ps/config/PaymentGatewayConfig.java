package com.amps.advanced_merchant_ps.config;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import com.amps.advanced_merchant_ps.model.Gateway;

@Configuration
@ConfigurationProperties(prefix = "payment")
public class PaymentGatewayConfig {

    private List<Gateway> gateways;

    public List<Gateway> getGateways() {
        return gateways;
    }

    public void setGateways(List<Gateway> gateways) {
        this.gateways = gateways;
    }
}
