package com.amps.advanced_merchant_ps.config;

import com.amps.advanced_merchant_ps.balancer.WeightedRoundRobinBalancer;
import com.amps.advanced_merchant_ps.model.Gateway;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class AppConfig {

    @Bean
    public WeightedRoundRobinBalancer weightedRoundRobinBalancer(PaymentGatewayConfig gatewayConfig) {
        List<Gateway> gateways = gatewayConfig.getGateways();
        if (gateways == null || gateways.isEmpty()) {
            throw new IllegalStateException("Gateways configuration is not loaded correctly.");
        }
        return new WeightedRoundRobinBalancer(gateways);
    }
}
