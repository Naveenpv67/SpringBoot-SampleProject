package com.amps.advanced_merchant_ps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvancedMerchantPsApplicationTests {

	@Test
	void contextLoads() {
	}

}
