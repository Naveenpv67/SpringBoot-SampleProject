package com.amps.fss_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FssGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
