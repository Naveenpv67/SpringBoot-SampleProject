package com.amps.fss_gateway.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.amps.fss_gateway.model.PaymentRequest;
import com.amps.fss_gateway.model.PaymentResponse;

@RestController
public class FSSGatewayController {
    private static final Logger logger = LoggerFactory.getLogger(FSSGatewayController.class);

    @PostMapping("/processPayment")
    public PaymentResponse processPayment(@RequestBody PaymentRequest request) {
        logger.info("FSS Gateway received payment request: userId={}, amount={}", request.getUserId(), request.getAmount());

        // Mock response
        PaymentResponse response = new PaymentResponse();
        response.setStatus("SUCCESS");
        response.setTransactionId("FSS123456");

        logger.info("FSS Gateway sending payment response: status={}, transactionId={}", response.getStatus(), response.getTransactionId());
        return response;
    }
}
