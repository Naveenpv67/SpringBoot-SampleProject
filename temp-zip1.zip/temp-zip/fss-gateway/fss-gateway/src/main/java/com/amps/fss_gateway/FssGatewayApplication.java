package com.amps.fss_gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FssGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(FssGatewayApplication.class, args);
	}

}
