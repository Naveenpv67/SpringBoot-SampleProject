package com.amps.payment_service.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amps.payment_service.model.PaymentRequest;
import com.amps.payment_service.model.PaymentResponse;
import com.amps.payment_service.service.PaymentService;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    private static final Logger logger = LoggerFactory.getLogger(PaymentController.class);
    private final PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping("/process")
    public ResponseEntity<PaymentResponse> processPayment(@RequestBody PaymentRequest request) {
        logger.info("Received payment request for userId: {}", request.getUserId());

        PaymentResponse response = paymentService.processPayment(request);
        if (response != null) {
            logger.info("Returning response: {}", response);
            return ResponseEntity.ok(response);
        } else {
            logger.error("Error in payment processing");
            return ResponseEntity.badRequest().build();
        }
    }
}
