// src/main/java/com/example/paymentservice/service/PaymentService.java
package com.amps.payment_service.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.amps.payment_service.model.PaymentRequest;
import com.amps.payment_service.model.PaymentResponse;

@Service
public class PaymentService {

    private static final Logger logger = LoggerFactory.getLogger(PaymentService.class);
    private final WebClient webClient;

    @Autowired
    public PaymentService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("http://localhost:8082/amps").build();
    }

    public PaymentResponse processPayment(PaymentRequest request) {
        logger.info("Processing payment for userId: {} with amount: {}", request.getUserId(), request.getAmount());

        try {
            PaymentResponse response = webClient.post()
                    .uri("/process")
                    .bodyValue(request)
                    .retrieve()
                    .bodyToMono(PaymentResponse.class)
                    .block(); // Block to get the response synchronously

            logger.info("Received response: {}", response);
            return response;
        } catch (Exception e) {
            logger.error("Error processing payment", e);
            return null; // Or handle the error as appropriate
        }
    }
}
