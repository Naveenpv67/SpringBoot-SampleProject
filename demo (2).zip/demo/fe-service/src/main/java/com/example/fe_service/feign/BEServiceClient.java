package com.example.fe_service.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "BE-SERVICE", url = "localhost:8082")
public interface BEServiceClient {

	@GetMapping("/api/be/hi")
	public ResponseEntity<String> sayHi();

}