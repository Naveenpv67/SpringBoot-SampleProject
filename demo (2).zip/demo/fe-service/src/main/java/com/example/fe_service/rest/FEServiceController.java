package com.example.fe_service.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.fe_service.service.FEService;

@RestController

@RequestMapping("/api")

public class FEServiceController {

	@Autowired

	private FEService fEService;

	@GetMapping("/fe/hi")

	public String sayHi() {

		return fEService.sayHi();

	}

}