package com.example.be_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NPBIServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
