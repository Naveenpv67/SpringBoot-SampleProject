package com.example.be_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
