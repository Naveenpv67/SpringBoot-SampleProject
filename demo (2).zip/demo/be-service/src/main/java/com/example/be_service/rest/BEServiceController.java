package com.example.be_service.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.be_service.service.BEService;

@RestController
@RequestMapping("/api")
public class BEServiceController {

	@Autowired
	private BEService bEService;

	@GetMapping("/be/hi")
	public ResponseEntity<String> sayHi() {

		String string = bEService.sayHi();
		return ResponseEntity.ok(string);

	}

}