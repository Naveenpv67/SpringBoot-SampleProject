package com.example.be_service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.be_service.feign.NPBIServiceClient;

@Service
public class BEService {

	@Autowired
	private NPBIServiceClient nPBIServiceClient;

	public String sayHi() {

		ResponseEntity<String> responseEntity = nPBIServiceClient.sayHi();
		return responseEntity.getBody();

	}
}