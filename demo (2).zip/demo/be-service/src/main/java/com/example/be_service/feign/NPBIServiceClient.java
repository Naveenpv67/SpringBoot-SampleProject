package com.example.be_service.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(name = "NPBI-SERVICE", url = "localhost:8083")
public interface NPBIServiceClient {

	@GetMapping("/api/npbi/hi")
	public ResponseEntity<String> sayHi();

}