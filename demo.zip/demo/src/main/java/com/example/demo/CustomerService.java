package com.example.demo;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {

    @Autowired
    private GenericRepository<Customer, Long> genericRepository;

    public Customer saveCustomer(Customer customer) {
        return genericRepository.save(customer);
    }

    public List<Customer> getAllCustomers() {
        return genericRepository.findAll();
    }

    // Add more methods as needed...
}
