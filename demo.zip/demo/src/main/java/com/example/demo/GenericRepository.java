package com.example.demo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GenericRepository<T, U> extends JpaRepository<T, U> {
    // Define any generic methods that should apply to all entities
}
