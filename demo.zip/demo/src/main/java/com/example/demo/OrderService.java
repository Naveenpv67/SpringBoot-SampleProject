package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {

    @Autowired
    private GenericRepository<CustomerOrder, Long> genericRepository;

    public CustomerOrder saveOrder(CustomerOrder order) {
        return genericRepository.save(order);
    }

    public List<CustomerOrder> getAllOrders() {
        return genericRepository.findAll();
    }

    public CustomerOrder getOrderById(Long id) {
        return genericRepository.findById(id).orElse(null);
    }

    public void deleteOrder(Long id) {
        genericRepository.deleteById(id);
    }
    
    // Additional custom queries or methods can be added as needed
}
