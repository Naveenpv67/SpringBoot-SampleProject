package com.bms.biller_service.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bms.biller_service.service.DummyService;

@RestController
public class DummyController {

    @Autowired
    private DummyService dummyService;

    @GetMapping("/test-third-party")
    public String testThirdPartyCall() {
        return dummyService.callApi1();
    }
}
