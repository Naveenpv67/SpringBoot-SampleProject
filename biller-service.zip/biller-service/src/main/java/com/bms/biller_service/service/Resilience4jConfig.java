package com.bms.biller_service.service;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;

@Configuration
public class Resilience4jConfig {

    @Value("${circuitbreaker.slidingWindowSize}")
    private int slidingWindowSize;

    @Value("${circuitbreaker.minimumNumberOfCalls}")
    private int minimumNumberOfCalls;

    @Value("${circuitbreaker.failureRateThreshold}")
    private float failureRateThreshold;

    @Value("${circuitbreaker.waitDurationInOpenState}")
    private long waitDurationInOpenState;

    @Value("${circuitbreaker.permittedNumberOfCallsInHalfOpenState}")
    private int permittedNumberOfCallsInHalfOpenState;

    @Bean
    public CircuitBreaker defaultCircuitBreaker(CircuitBreakerRegistry registry) {
        CircuitBreakerConfig config = CircuitBreakerConfig.custom()
                .slidingWindowSize(slidingWindowSize)
                .minimumNumberOfCalls(minimumNumberOfCalls)
                .failureRateThreshold(failureRateThreshold)
                .waitDurationInOpenState(Duration.ofMillis(waitDurationInOpenState))
                .permittedNumberOfCallsInHalfOpenState(permittedNumberOfCallsInHalfOpenState)
                .build();
        return registry.circuitBreaker("defaultCircuitBreaker", config);
    }
}
