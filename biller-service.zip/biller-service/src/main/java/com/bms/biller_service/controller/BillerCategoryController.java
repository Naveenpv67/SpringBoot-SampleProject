package com.bms.biller_service.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bms.biller_service.entity.BillerCategory;
import com.bms.biller_service.service.BillerCategoryService;

@RestController
@RequestMapping("/api/biller-categories")
public class BillerCategoryController {

    @Autowired
    private BillerCategoryService billerCategoryService;

    @GetMapping
    public List<BillerCategory> getAllBillerCategories() {
        return billerCategoryService.getAllBillerCategories();
    }

    @PostMapping
    public BillerCategory createBillerCategory(@RequestBody BillerCategory billerCategory) {
        return billerCategoryService.saveBillerCategory(billerCategory);
    }

    @DeleteMapping("/{billerCategoryId}")
    public void deleteBillerCategory(@PathVariable Long billerCategoryId) {
        billerCategoryService.deleteBillerCategory(billerCategoryId);
    }
}
