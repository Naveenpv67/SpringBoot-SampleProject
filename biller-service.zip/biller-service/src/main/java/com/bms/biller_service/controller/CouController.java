package com.bms.biller_service.controller;

import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bms.biller_service.service.CouService;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/cou")
public class CouController {

    private final CouService couService;

    @Autowired
    public CouController(CouService couService) {
        this.couService = couService;
    }

    @PostMapping("/bill-details")
    public Mono<String> fetchBillDetails(@RequestBody Map<String, Object> requestPayload) {
        // Generate requestReferenceId
        String requestReferenceId = UUID.randomUUID().toString();
        
        // Log requestReferenceId in controller
        System.out.println("Request Reference ID (Controller): " + requestReferenceId);

        // Set requestReferenceId in request payload
        requestPayload.put("requestReferenceId", requestReferenceId);

        // Call service layer
        return couService.fetchBillDetails(requestPayload);
    }

    @PostMapping("/plan-details")
    public Mono<String> fetchPlanDetails(@RequestBody Map<String, Object> requestPayload) {
        // Generate requestReferenceId
        String requestReferenceId = UUID.randomUUID().toString();

        // Log requestReferenceId in controller
        System.out.println("Request Reference ID (Controller): " + requestReferenceId);

        // Set requestReferenceId in request payload
        requestPayload.put("requestReferenceId", requestReferenceId);

        // Call service layer
        return couService.fetchPlanDetails(requestPayload);
    }
}
