package com.bms.biller_service.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class DummyService {

    @Autowired
    private WebClient.Builder webClientBuilder;

    @Autowired
    private WebClientUtilsHelper webClientUtilsHelper;

    @CircuitBreaker(name = "defaultCircuitBreaker", fallbackMethod = "fallbackForApi1")
    public String callApi1() {
        WebClient webClient = webClientBuilder.build();
        String url = "https://jsonplaceholder.typicode.com/post";
        Map<String, Object> payload = new HashMap<>();
        payload.put("title", "foo");
        payload.put("body", "bar");
        payload.put("userId", 1);
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");

        ResponseEntity<String> responseEntity = webClientUtilsHelper.makeRequest(
                webClient,
                url,
                HttpMethod.POST,
                payload,
                String.class,
                headers
        );

        if (responseEntity.getStatusCode().is2xxSuccessful()) {
            return responseEntity.getBody();
        } else {
            return "Request failed with status: " + responseEntity.getStatusCode();
        }
    }

    @CircuitBreaker(name = "defaultCircuitBreaker", fallbackMethod = "fallbackForApi2")
    public String callApi2() {
        WebClient webClient = webClientBuilder.build();
        String url = "https://anotherapi.com/resource";
        Map<String, Object> payload = new HashMap<>();
        payload.put("key", "value");
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "Bearer token");

        ResponseEntity<String> responseEntity = webClientUtilsHelper.makeRequest(
                webClient,
                url,
                HttpMethod.GET,
                payload,
                String.class,
                headers
        );

        if (responseEntity.getStatusCode().is2xxSuccessful()) {
            return responseEntity.getBody();
        } else {
            return "Request failed with status: " + responseEntity.getStatusCode();
        }
    }

    // Fallback methods
    public String fallbackForApi1(Throwable throwable) {
        return "Fallback response for API 1.";
    }

    public String fallbackForApi2(Throwable throwable) {
        return "Fallback response for API 2.";
    }
}
