package com.bms.biller_service.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class BillerCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long billerCategoryId;

    private String name;

    // Constructors, getters, and setters

    public BillerCategory() {
    }

    public BillerCategory(String name) {
        this.name = name;
    }

    // Getters and Setters

    public Long getBillerCategoryId() {
        return billerCategoryId;
    }

    public void setBillerCategoryId(Long billerCategoryId) {
        this.billerCategoryId = billerCategoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
