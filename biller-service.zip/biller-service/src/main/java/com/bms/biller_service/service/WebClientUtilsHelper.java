package com.bms.biller_service.service;

import java.time.Duration;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

@Component
public class WebClientUtilsHelper {
	
    private static final Logger logger = LoggerFactory.getLogger(WebClientUtilsHelper.class);

    @Value("${webclient.timeout.duration:5}") // 5 seconds as default
    private int timeoutDuration;

    @Value("${webclient.retry.max-retries:3}") // Default max retries
    private int maxRetries;

    @Value("${webclient.retry.fixed-delay-seconds:2}") // Default retry delay
    private long fixedDelaySeconds;

    public <T> ResponseEntity<T> makeRequest(WebClient webClient, String url, HttpMethod method, Object payload, Class<T> responseClass,
                                             Map<String, String> headers) {
        try {
            if (method == HttpMethod.POST) {
                return webClient.post()
                        .uri(url)
                        .headers(httpHeaders -> Optional.ofNullable(headers).ifPresent(h -> h.forEach(httpHeaders::set)))
                        .bodyValue(payload)
                        .retrieve()
                        .onStatus(HttpStatusCode::is4xxClientError, response -> handle4xxError(response))
                        .onStatus(HttpStatusCode::is5xxServerError, response -> handle5xxError(response))
                        .toEntity(responseClass)
                        .timeout(Duration.ofSeconds(timeoutDuration))
                        .retryWhen(Retry.fixedDelay(maxRetries, Duration.ofSeconds(fixedDelaySeconds))
                                .doBeforeRetry(retrySignal -> logger.info("Retry attempt {} for URL: {}", retrySignal.totalRetries() + 1, url))
                                .onRetryExhaustedThrow((retryBackoffSpec, retrySignal) -> {
                                    logger.error("Max retries exhausted for URL: {}", url);
                                    return new CustomException("RETRY_FAILED", "Max retries exhausted");
                                }))
                        .onErrorMap(throwable -> {
                            if (throwable instanceof TimeoutException) {
                                logger.error("Timeout occurred for URL: {}: {}", url, throwable.getMessage());
                                return new CustomException("TIMEOUT", "Request timed out");
                            } else {
                                logger.error("Error occurred for URL: {}: {}", url, throwable.getMessage());
                                return new CustomException("GENERAL_ERROR", "An unexpected error occurred");
                            }
                        })
                        .block();
            } else {
                throw new CustomException("UNSUPPORTED_METHOD", "HTTP method not supported yet.");
            }
        } catch (CustomException e) {
            logger.error("Custom exception occurred: Code - {}, Message - {}", e.getCode(), e.getMessage());
            throw e;
        } catch (Exception e) {
            logger.error("An unexpected error occurred: {}", e.getMessage());
            throw new CustomException("GENERAL_ERROR", "An unexpected error occurred: " + e.getMessage());
        }
    }

    private Mono<? extends Throwable> handle4xxError(ClientResponse response) {
        String errorMsg = "Client Error: " + response.statusCode() + " " + response.bodyToMono(String.class).block();
        logger.error(errorMsg);
        return Mono.error(new CustomException("4XX_ERROR", errorMsg));
    }

    private Mono<? extends Throwable> handle5xxError(ClientResponse response) {
        String errorMsg = "Server Error: " + response.statusCode() + " " + response.bodyToMono(String.class).block();
        logger.error(errorMsg);
        return Mono.error(new CustomException("5XX_ERROR", errorMsg));
    }
}
